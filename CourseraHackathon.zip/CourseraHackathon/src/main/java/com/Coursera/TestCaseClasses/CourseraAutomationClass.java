package com.Coursera.TestCaseClasses;

import java.util.Hashtable;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.Coursera.Base.BaseTestClass;
import com.Coursera.Base.PageBaseClass;
import com.Coursera.PageClasses.CoursesPage;
import com.Coursera.PageClasses.ForEnterprisePage;
import com.Coursera.PageClasses.LandingPage;
import com.Coursera.PageClasses.ProductPage;
import com.Coursera.Utils.TestDataProvider;

public class CourseraAutomationClass extends BaseTestClass {
	LandingPage landingPage;
	CoursesPage coursespage;
	ForEnterprisePage forenterprisepage;
	ProductPage productPage;
	
	
	@Test(dataProvider="getCourseName",priority=0)
	public void selectRequiredCourse(Hashtable<String, String> testData) {
		logger = report.createTest("Select Course : " + testData.get("Comment"));
		
		invokeBrowser("chrome");
		PageBaseClass pageBase = new PageBaseClass(driver, logger, prop);
		PageFactory.initElements(driver, pageBase);
		landingPage = pageBase.OpenApplication("websiteURL");
		String courseName=testData.get("CourseName");
		if(courseName.contentEquals("Blank"))
			landingPage.blankCourse("searchField_Xpath", courseName, "searchbutton_Xpath", testData.get("PageTitle"));
		else if(courseName.equalsIgnoreCase("web development"))
		{
			coursespage=landingPage.SearchCourse("searchField_Xpath", courseName, "searchbutton_Xpath");
			coursespage.wdCourses("LanguageForCourse","LevelForCourse");
		}
		else if(courseName.equalsIgnoreCase("language learning"))
		{
			coursespage=landingPage.SearchCourse("searchField_Xpath", courseName, "searchbutton_Xpath");
			coursespage.lcourses();
		}
		
		
	}
	
	@Test(dataProvider="getDataForForm",priority=1)
	public void goToEnterprise(Hashtable<String, String> testData)
	{
		logger = report.createTest("ForEnterprise Registration "+testData.get("Comment"));
		
		invokeBrowser("chrome");
		PageBaseClass pageBase = new PageBaseClass(driver, logger, prop);
		PageFactory.initElements(driver, pageBase);
		landingPage = pageBase.OpenApplication("websiteURL");
		forenterprisepage=landingPage.landOnEnterprisePage("forEnterPrise_Xpath");
		productPage=forenterprisepage.SelectProduct();
		productPage.fillForm(testData);
		
	}
	
	
	
	@DataProvider
	public Object[][] getCourseName(){
		return TestDataProvider.getTestData("CourseraPagesData.xlsx", "CourseraPageTest", "openCourseraPage");
	}
	
	@DataProvider
	public Object[][] getDataForForm(){
		return TestDataProvider.getTestData("CourseraPagesData.xlsx", "CourseraPageTest", "dataForFillingForm");
	}
}
