package com.Coursera.PageClasses;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.Coursera.Base.PageBaseClass;
import com.aventstack.extentreports.ExtentTest;

public class ForEnterprisePage extends PageBaseClass{

	public ForEnterprisePage(WebDriver driver, ExtentTest logger, Properties prop) {
		super(driver, logger,prop);
	}
	public  ProductPage SelectProduct() {
		ProductPage productPage=new ProductPage(driver,logger,prop);
		PageFactory.initElements(driver, productPage);
		Actions action = new Actions(driver);
		action.moveToElement(getElement("product_Xpath")).build().perform();
		elementClick("CourseraForCampus_Xpath");
		return productPage;
		
	}

}
