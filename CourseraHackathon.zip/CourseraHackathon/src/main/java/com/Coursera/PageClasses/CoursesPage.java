package com.Coursera.PageClasses;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.Coursera.Base.PageBaseClass;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class CoursesPage extends PageBaseClass{
	public CoursesPage(WebDriver driver, ExtentTest logger, Properties prop) {
		super(driver, logger,prop);
	}
	public ArrayList<String>namesList = new ArrayList<String>();
	public ArrayList<String>ratingList=new ArrayList<String>();
	public ArrayList<String>hoursList = new ArrayList<String>();
	
	public void wdCourses(String LanguageKey,String LevelKey) 
	{
		int i=1;
		elementClick("LanguageFilter_Xpath");
		SelectElementInList("CommonLanguageFiter_Xpath",LanguageKey);
		waitForPageLoad();
		elementClick("LevelFilter_Xpath");
		SelectElementInList("CommonLevelFilter_Xpath",LevelKey);
		waitForPageLoad();
		logger.log(Status.INFO, "Extracting details of Courses");
		List<WebElement> listElements = driver.findElements(By.xpath(prop.getProperty("topCoursesCommon_Xpath")));
		for(WebElement cElement:listElements) {
			if(i<=2)
			{
				WebElement cLink=cElement.findElement(By.xpath("./div/div/div/div[2]/div[1]/h2"));
				WebElement rLink=cElement.findElement(By.xpath("./div/div/div/div[2]/div[4]/div[1]/div[1]/div/span[1]"));
				String name=cLink.getText();
				String rating=rLink.getText();
				ratingList.add(rating);
				namesList.add(name);
				/*String ParentHandle=driver.getWindowHandle();
				cElement.click();
				Set<String>allHandles=driver.getWindowHandles();
				if(allHandles.size()>1)
					this.driver=Multiplewindows(ParentHandle);
				else
					this.driver=SingleWindow(ParentHandle);
				waitForPageLoad();*/
				System.out.println("Course name- "+name+" and Rating- "+rating);
				logger.log(Status.INFO, "Course name- "+name+" and Rating- "+rating);
				i++;
			}
		}
		reportPass("Extracted details of courses");
	}
	
	public void lcourses() 
	{
		elementClick("LanguageFilter_Xpath");
		elementClick("Showall_Xpath");
		waitForElement("Closebutton_Xpath");
		ExtractDetails("Commonlistoflanguages_Xpath","NamesExtraPath_Xpath","CountExtraPath_Xpath","Languages");
		elementClick("Closebutton_Xpath");
		elementClick("LevelFilter_Xpath");
		ExtractDetails("Commonlistoflevels_Xpath","NamesExtraPath_Xpath","CountExtraPath_Xpath","Levels");
	}
}
