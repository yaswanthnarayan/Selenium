package com.Coursera.Base;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

import com.Coursera.PageClasses.LandingPage;
import com.Coursera.Utils.DateUtils;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;



public class PageBaseClass extends BaseTestClass {

	public ExtentTest logger;

	public PageBaseClass(WebDriver driver, ExtentTest logger,Properties prop) {
		this.driver = driver;
		this.logger = logger;
		this.prop = prop;
	}
	
	/****************** OpenApplication ***********************/
	public LandingPage OpenApplication(String websiteURLKey) {
		logger.log(Status.INFO, "Opening the WebSite");
		driver.get(prop.getProperty(websiteURLKey));
		logger.log(Status.PASS, "Successfully Opened the site");
		LandingPage landingPage = new LandingPage(driver, logger, prop);
		PageFactory.initElements(driver, landingPage);
		return landingPage;
	}

	/****************** Enter Text ***********************/
	public void enterText(String xpathKey, String data) {
		try {
			getElement(xpathKey).sendKeys(data);
			reportPass(data + " - Entered successfully in locator Element : " + xpathKey);
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}

	/****************** Click Element ***********************/
	public void elementClick(String xpathKey) {
		try {
			getElement(xpathKey).click();
			reportPass(xpathKey + " : Element Clicked Successfully");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}
	
	/**********************Select Dropdows**********************/
	public void selectItems(String pathKey,String value)
	{
		Select select = new Select(getElement(pathKey));
		select.selectByValue(value);
		logger.log(Status.PASS, "Selected "+value+" from dropdown");
		
	}
	
	/****************** Select List Drop Down ******************/
	public void SelectElementInList(String locatorXpath, String Valuekey){
		try{
			String Value=prop.getProperty(Valuekey);
			List<WebElement> listElement = driver.findElements(By.xpath(prop.getProperty(locatorXpath)));
			for (WebElement listItem : listElement) {
				String req=listItem.findElement(By.xpath("./span[2]/div")).getText();
				if(req.equalsIgnoreCase(Value)){
					listItem.findElement(By.xpath("./input")).click();
					waitForPageLoad();
					break;
				}
			}
			logger.log(Status.INFO, "Selected the Filter Value : " +Value);
		}catch (Exception e){
			reportFail(e.getMessage());
		}
	}
	

/****************** Identify Element ***********************/
	public WebElement getElement(String locatorKey) {
		WebElement element = null;

		try {
			if (locatorKey.endsWith("_Id")) {
				element = driver.findElement(By.id(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_Xpath")) {
				element = driver.findElement(By.xpath(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_ClassName")) {
				element = driver.findElement(By.className(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_CSS")) {
				element = driver.findElement(By.cssSelector(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_LinkText")) {
				element = driver.findElement(By.linkText(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_PartialLinkText")) {
				element = driver.findElement(By.partialLinkText(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else if (locatorKey.endsWith("_Name")) {
				element = driver.findElement(By.name(prop.getProperty(locatorKey)));
				logger.log(Status.INFO, "Locator Identified : " + locatorKey);
			} else {
				reportFail("Failing the Testcase, Invalid Locator " + locatorKey);
			}
		} catch (Exception e) {

			// Fail the TestCase and Report the error
			reportFail(e.getMessage());
			e.printStackTrace();
		}

		return element;
	}
	
	
	/****************** Assertion Functions ***********************/
	public void assertTrue(boolean flag) {
		try{
			Assert.assertTrue(flag);
		}catch(AssertionError e){
			reportFail(e.getMessage());
		}
	}

	public void assertfalse(boolean flag) {
		try{
			Assert.assertFalse(flag);
		}catch(AssertionError e){
			reportFail(e.getMessage());
		}
	}

	public void assertequals(String actual, String expected) {
		try{
			Assert.assertEquals(actual, expected);
		}catch(AssertionError e){
			reportFail("Assertion Failed");
		}
		
	}
	/****************** Reporting Functions ***********************/
	public void reportFail(String reportString) {
		waitForPageLoad();
		takeScreenShotOnFailure(reportString);
		logger.log(Status.FAIL, reportString);
		Assert.fail(reportString);
	}

	public void reportPass(String reportString) {
		logger.log(Status.PASS, reportString);
	}

	@AfterMethod
	public void afterTest() {
		softAssert.assertAll();
		driver.quit();
	}

	/********************Multiple Handle***********************/
	public WebDriver mulWindows(WebDriver driver) {
		String parent=driver.getWindowHandle();
		Set<String> Handles= driver.getWindowHandles();
		for(String handle:Handles) {
			if(!parent.equalsIgnoreCase(handle)) {
				driver.switchTo().window(handle);
				return driver;
			}
		}
		return driver;
		
	}
	
	
	/********************wait for visibility*******************/
	public void waitForElement(String xpathKey)
	{
		WebDriverWait wait1 = new WebDriverWait(driver, 20); 
		wait1.until(ExpectedConditions.visibilityOf(getElement(xpathKey)));
	}
	/****************** Verify Element ***********************/
	
	public void verifyPageTitle(String pageTitle) {
		try {
			String actualTite = driver.getTitle();
			logger.log(Status.INFO, "Actual Title is : " + actualTite);
			logger.log(Status.INFO, "Expected Title is : " + pageTitle);
			assertequals(actualTite, pageTitle);
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}
	/******************ExtractDetails******************************/
	public void ExtractDetails(String CommonPath,String nameExtraPath, String countExtrapath, String Filter)
	{
		List<WebElement> listElements = driver.findElements(By.xpath(prop.getProperty(CommonPath)));
		logger.log(Status.INFO, "Extracting count and names of "+Filter+" available.");
		int countOfElements=listElements.size();
		if(!Filter.equalsIgnoreCase("languages")) countOfElements-=1;
		logger.log(Status.INFO, "Count of "+Filter+" available- "+countOfElements);
		System.out.println("/************************************/");
		System.out.println("Count of "+Filter+" available- "+countOfElements);
		for(WebElement cElement:listElements) 
		{
			if(!(cElement.getText()).equalsIgnoreCase("Clear"))
			{
			String name=cElement.findElement(By.xpath(prop.getProperty(nameExtraPath))).getText();
			String count=cElement.findElement(By.xpath(prop.getProperty(countExtrapath))).getText();
			System.out.println(name+" "+count);
			logger.log(Status.INFO,name+" "+count);
			}
		}
		reportPass("Extracted count and names of "+Filter+" available.");
		System.out.println("/************************************/");

	}
	
	/****************** Capture Screen Shot ***********************/
	public void takeScreenShotOnFailure(String reportMessage) {
		TakesScreenshot takeScreenShot = (TakesScreenshot) driver;
		logger.log(Status.INFO, reportMessage);
		File sourceFile = takeScreenShot.getScreenshotAs(OutputType.FILE);
		String fileName=reportMessage +" "+ DateUtils.getTimeStamp() + ".png";
		File destFile = new File(System.getProperty("user.dir") + "\\ScreenShots\\" + fileName);
		try {
			FileUtils.copyFile(sourceFile, destFile);
			logger.addScreenCaptureFromPath(System.getProperty("user.dir") + "\\ScreenShots\\" + fileName);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
