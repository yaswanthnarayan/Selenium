package com.Coursera.PageClasses;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.Coursera.Base.PageBaseClass;
import com.aventstack.extentreports.ExtentTest;

public class LandingPage extends PageBaseClass  {
	public LandingPage(WebDriver driver, ExtentTest logger, Properties prop) {
		super(driver, logger,prop);
	}
	public CoursesPage SearchCourse(String searchFieldkey, String courseName, String searchButtonkey) {
		CoursesPage coursespage= new CoursesPage(driver,logger,prop);
		enterText(searchFieldkey,courseName);
		elementClick(searchButtonkey);
		PageFactory.initElements(driver, coursespage);
		return coursespage;
		
	}
	public ForEnterprisePage landOnEnterprisePage(String forEnterPrise_Xpath) 
	{
		ForEnterprisePage forenterprisepage=new ForEnterprisePage(driver,logger,prop);
		elementClick(forEnterPrise_Xpath);
		waitForPageLoad();
		PageFactory.initElements(driver, forenterprisepage);
		return forenterprisepage;
		
	}
	public void blankCourse(String searchFieldkey, String courseName, String searchButtonkey, String pageTitle) {
		courseName="";
		enterText(searchFieldkey,courseName);
		elementClick(searchButtonkey);
		verifyPageTitle(pageTitle);
	}
}
