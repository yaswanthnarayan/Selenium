package com.Coursera.PageClasses;

import java.util.Hashtable;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import com.Coursera.Base.PageBaseClass;
import com.aventstack.extentreports.ExtentTest;

public class ProductPage extends PageBaseClass {
	public ProductPage(WebDriver driver, ExtentTest logger, Properties prop) {
		super(driver, logger,prop);
	}
	public void fillForm(Hashtable<String, String> testData)
	{
		this.driver=mulWindows(driver);
		elementClick("GetStarted_Xpath");
		fillingForm(testData);
		
		
	}
	
	public void fillingForm(Hashtable<String, String> testData) {
		enterText("FirstName_Xpath",testData.get("First Name"));
		enterText("LastName_Xpath",testData.get("Last Name"));
		enterText("Email_Xpath",testData.get("Email"));
		enterText("JobTitle_Xpath",testData.get("JobTitle"));
		enterText("Number_Xpath",testData.get("Number"));
		enterText("Institution_Xpath",testData.get("InstName"));
		selectItems("InstType_Xpath",testData.get("InstType"));
		selectItems("No.OfStudents_Xpath",testData.get("StudentsCount"));
		selectItems("ExpectedUsers_Xpath",testData.get("UsersCount"));
		selectItems("Country_Xpath",testData.get("Country"));
		selectItems("State_Xpath",testData.get("State"));
		elementClick("ConnectWithUs_Xpath");
		waitForPageLoad();
		String title=driver.getTitle();
		if(testData.get("PageTitle").equalsIgnoreCase(title)){
			takeScreenShotOnFailure("Warning Occured while Submitting form");
			reportPass("Successfully generated error message");
		}
		else reportPass("Successfully Completed Registration and landed on next page");
		
		
	}

}
